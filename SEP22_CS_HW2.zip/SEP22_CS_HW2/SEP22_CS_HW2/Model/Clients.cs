﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEP22_CS_HW2.Model
{
    class Clients
    {
        public int ClientId { get; set; }
        public string CompanyName { get; set; }
        public string Contact { get; set; }
        
    }
}
