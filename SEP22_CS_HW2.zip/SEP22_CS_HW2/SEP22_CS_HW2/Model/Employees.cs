﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEP22_CS_HW2.Model
{
    class Employees
    {
        public int EmployeeID { get; set; }
        public string FullName { get; set; }
        public string Department { get; set; }
    }
}
