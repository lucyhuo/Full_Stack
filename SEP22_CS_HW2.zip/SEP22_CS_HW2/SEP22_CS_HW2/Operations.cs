﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEP22_CS_HW2
{
    enum Options
    {
        Clients = 1,
        Employees
    }

    enum Operations
    {
        Add = 1,
        Delete, 
        Print,
        Exit
    }
}
