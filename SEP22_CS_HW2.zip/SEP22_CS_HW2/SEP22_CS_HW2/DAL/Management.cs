﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEP22_CS_HW2.DAL
{
    /**
     * An abstract class 
     */
    abstract class Management
    {
        public abstract void Run();
    }
}
