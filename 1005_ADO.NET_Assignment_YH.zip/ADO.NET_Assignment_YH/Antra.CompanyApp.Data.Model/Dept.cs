﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Antra.CompanyApp.Data.Model
{
    public class Dept
    {
        public int Id { get; set; }
        public string DName { get; set; }
        public string Loc { get; set; }
    }
}
