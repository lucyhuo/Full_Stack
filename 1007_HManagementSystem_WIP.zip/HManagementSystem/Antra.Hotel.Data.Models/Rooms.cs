﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Antra.Hotel.Data.Models
{
    public class Rooms
    {
        public int Id { get; set; }
        public int RTCODE { get; set; }
        public string Status { get; set; }
    }
}
