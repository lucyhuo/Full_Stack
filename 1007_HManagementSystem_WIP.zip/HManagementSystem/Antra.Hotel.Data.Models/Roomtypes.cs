﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Antra.Hotel.Data.Models
{
    public class Roomtypes
    {
        public int Id { get; set; }
        public string RTDESC { get; set; }
        public double Rent { get; set; }
    }
}
