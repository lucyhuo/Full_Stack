﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Antra.Hotel.ConsoleApp
{
    enum Options
    {
        Roomtypes = 1,
        Rooms,
        Customers,
        Services
    }

    enum Operations
    {
        Add = 1,
        Update,
        Delete, 
        Print,
        Exit
    }
}
