﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Antra.Hotel.ConsoleApp
{
    /**
     * An abstract class 
     */
    abstract class Management
    {
        public abstract void Run();
    }
}
